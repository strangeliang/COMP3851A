import { BookOpenText, MessageCircleQuestion, Sparkles } from "lucide-react";

export const STUDY_MODES = [
  ["summary", "Summary", BookOpenText],
  ["qa", "Q&A", MessageCircleQuestion],
  ["quiz", "Quiz", Sparkles],
];

export const STUDY_MODE_KEYS = STUDY_MODES.map(([key]) => key);
