import { CheckCircle2, RotateCcw } from "lucide-react";
import { useState } from "react";
import { quizQuestions } from "../../../data/mockData";

export default function QuizPanel({ canUseAI, materialSourceLabel, selectedMaterialIds, onCompleted }) {
  const [quizIndex, setQuizIndex] = useState(0);
  const [answers, setAnswers] = useState({});
  const [submitted, setSubmitted] = useState(false);
  const [warning, setWarning] = useState("");
  const selectedCount = Object.keys(answers).length;
  const scoreCount = quizQuestions.reduce((sum, item) => sum + (answers[item.id] === item.answerIndex ? 1 : 0), 0);
  const scorePercent = Math.round((scoreCount / quizQuestions.length) * 100);
  const currentQuestion = quizQuestions[quizIndex];

  function submit() {
    if (!canUseAI) return;
    if (selectedCount !== quizQuestions.length) {
      setWarning("Please answer every question before submitting.");
      return;
    }
    setWarning("");
    setSubmitted(true);
    onCompleted({ score: scorePercent, total: quizQuestions.length, correct: scoreCount, answers, selectedMaterialIds });
  }

  function retake() {
    setQuizIndex(0);
    setAnswers({});
    setSubmitted(false);
    setWarning("");
  }

  return (
    <section className="user-card workspace-panel">
      <div className="panel-title-row">
        <div><p className="summary-source">{materialSourceLabel}</p><h2>Quiz</h2></div>
        {submitted && <div className="score-card"><CheckCircle2 size={18} /> {scorePercent}% ({scoreCount}/{quizQuestions.length})</div>}
      </div>
      <p className="demo-warning">Quiz questions are fixed mock data, but answer selection and scoring are real.</p>
      {!submitted ? (
        <div className="quiz-card">
          <div className="quiz-counter">Question {quizIndex + 1} of {quizQuestions.length}</div>
          <h3>{currentQuestion.question}</h3>
          <div className="quiz-options">
            {currentQuestion.options.map((option, optionIndex) => (
              <label key={option} className={answers[currentQuestion.id] === optionIndex ? "selected" : ""}>
                <input type="radio" name={`question-${currentQuestion.id}`} checked={answers[currentQuestion.id] === optionIndex} onChange={() => setAnswers((current) => ({ ...current, [currentQuestion.id]: optionIndex }))} disabled={!canUseAI} />
                {option}
              </label>
            ))}
          </div>
          {warning && <p className="form-error">{warning}</p>}
          <div className="quiz-actions">
            <button type="button" disabled={quizIndex === 0} onClick={() => setQuizIndex((index) => index - 1)}>Previous</button>
            <button type="button" disabled={quizIndex === quizQuestions.length - 1} onClick={() => setQuizIndex((index) => index + 1)}>Next</button>
            <button className="primary-button" type="button" disabled={!canUseAI} onClick={submit}>Submit</button>
          </div>
        </div>
      ) : (
        <div className="quiz-review">
          {quizQuestions.map((item) => (
            <article key={item.id}><h3>{item.question}</h3><p><strong>Your answer:</strong> {item.options[answers[item.id]]}</p><p><strong>Correct answer:</strong> {item.options[item.answerIndex]}</p><p><strong>Explanation:</strong> {item.explanation}</p></article>
          ))}
          <button className="primary-button" type="button" onClick={retake}><RotateCcw size={16} /> Retake Quiz</button>
        </div>
      )}
    </section>
  );
}
