import { useState } from "react";
import { mockSummary } from "../../../data/mockData";

export default function SummaryPanel({ canUseAI, materialSourceLabel, selectedMaterials, onGenerated }) {
  const [status, setStatus] = useState("idle");
  const [error, setError] = useState("");

  function generateSummary() {
    if (!canUseAI) return;
    setError("");
    setStatus("loading");
    window.setTimeout(() => {
      if (selectedMaterials.some((material) => material.name.toLowerCase().includes("error"))) {
        setError("Mock error: one selected material failed to generate a summary.");
        setStatus("error");
        return;
      }
      onGenerated(mockSummary);
      setStatus("success");
    }, 520);
  }

  return (
    <section className="user-card workspace-panel">
      <div className="panel-title-row">
        <div><p className="summary-source">{materialSourceLabel}</p><h2>Generate Summary</h2></div>
        <button className="primary-button" type="button" disabled={!canUseAI || status === "loading"} onClick={generateSummary}>
          {status === "loading" ? "Generating..." : status === "success" ? "Regenerate" : "Generate Summary"}
        </button>
      </div>
      <p className="demo-warning">AI content shown here is mock demo data only.</p>
      {status === "idle" && <div className="empty-state">No summary generated yet.</div>}
      {status === "loading" && <div className="state-banner">Loading mock summary...</div>}
      {status === "error" && <div className="state-banner error">{error}<button type="button" onClick={generateSummary}>Retry</button></div>}
      {status === "success" && (
        <div className="summary-result">
          <p>{mockSummary.paragraph}</p>
          <h3>Key Concepts</h3>
          <div className="key-concepts">{mockSummary.concepts.map((concept) => <span key={concept}>{concept}</span>)}</div>
        </div>
      )}
    </section>
  );
}
