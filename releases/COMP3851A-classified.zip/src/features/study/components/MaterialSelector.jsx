export default function MaterialSelector({
  materials,
  filteredMaterials,
  selectedMaterialIds,
  onSelectionChange,
}) {
  function isSelected(materialId) {
    return selectedMaterialIds.some((id) => String(id) === String(materialId));
  }

  function toggle(materialId) {
    const nextIds = isSelected(materialId)
      ? selectedMaterialIds.filter((id) => String(id) !== String(materialId))
      : [...selectedMaterialIds, materialId];
    onSelectionChange(nextIds);
  }

  return (
    <section className="user-card materials-ai-panel">
      <div className="materials-ai-header">
        <div>
          <p className="summary-source">Current course only</p>
          <h2>Materials for AI</h2>
        </div>
        <div className="materials-ai-actions">
          <button type="button" onClick={() => onSelectionChange(materials.map(({ id }) => id))} disabled={!materials.length}>
            Select All
          </button>
          <button type="button" onClick={() => onSelectionChange([])} disabled={!materials.length}>
            Clear All
          </button>
        </div>
      </div>

      {materials.length ? (
        <>
          <div className="materials-ai-list">
            {filteredMaterials.map((material) => (
              <label className="material-check-row" key={material.id}>
                <input type="checkbox" checked={isSelected(material.id)} onChange={() => toggle(material.id)} />
                <span>{material.name}</span>
                <strong>{material.type}</strong>
              </label>
            ))}
          </div>
          {!filteredMaterials.length && <div className="empty-state">No matching materials in this course.</div>}
          <p className="materials-selected-count">
            Selected: {selectedMaterialIds.length} material{selectedMaterialIds.length === 1 ? "" : "s"}
          </p>
        </>
      ) : (
        <div className="empty-state">No materials available. Please upload materials first.</div>
      )}
    </section>
  );
}
