import AIChatBox from "./AIChatBox";

export default function QAPanel({ currentCourse, materialSourceLabel, selectedMaterials }) {
  return (
    <section className="user-card workspace-panel">
      <div className="panel-title-row">
        <div><p className="summary-source">{materialSourceLabel}</p><h2>Q&amp;A Chat</h2></div>
      </div>
      <p className="demo-warning">Q&amp;A uses the selected course materials. The AIChatBox component is kept as the active chat interface.</p>
      <AIChatBox selectedMaterials={selectedMaterials} currentCourse={currentCourse} />
    </section>
  );
}
