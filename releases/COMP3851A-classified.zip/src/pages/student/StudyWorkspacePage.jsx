import { AlertCircle } from "lucide-react";
import { useEffect, useMemo, useRef, useState } from "react";
import { useSearchParams } from "react-router-dom";
import Toolbar from "../../components/common/Toolbar";
import MaterialSelector from "../../features/study/components/MaterialSelector";
import QAPanel from "../../features/study/components/QAPanel";
import QuizPanel from "../../features/study/components/QuizPanel";
import SummaryPanel from "../../features/study/components/SummaryPanel";
import { STUDY_MODE_KEYS, STUDY_MODES } from "../../features/study/config/studyModes";
import StudentLayout from "../../layouts/StudentLayout";
import { useAppData } from "../../state/AppDataContext";

export default function StudyWorkspacePage() {
  const [params] = useSearchParams();
  const requestedMode = params.get("mode");
  const initialMode = STUDY_MODE_KEYS.includes(requestedMode) ? requestedMode : "summary";
  const {
    studentCourses, currentCourse, currentCourseId, selectCourse, courseMaterials,
    selectedMaterialIds, selectedMaterials, setSelectedMaterialIds, summaryUses,
    qaUses, recordSummaryUse, saveQuizAttempt,
  } = useAppData();
  const [mode, setMode] = useState(initialMode);
  const [search, setSearch] = useState("");
  const hasDefaultedMaterials = useRef(false);
  const [defaultedCourseId, setDefaultedCourseId] = useState(currentCourseId);
  const canUseAI = Boolean(currentCourse && selectedMaterials.length);
  const materialSourceLabel = selectedMaterials.length
    ? `${selectedMaterials.length} material${selectedMaterials.length === 1 ? "" : "s"}: ${selectedMaterials.map(({ name }) => name).join(", ")}`
    : "No materials selected";

  useEffect(() => setMode(initialMode), [initialMode]);

  useEffect(() => {
    if (!hasDefaultedMaterials.current || defaultedCourseId !== currentCourseId) {
      setSelectedMaterialIds(courseMaterials.map(({ id }) => id));
      hasDefaultedMaterials.current = true;
      setDefaultedCourseId(currentCourseId);
    }
  }, [courseMaterials, currentCourseId, defaultedCourseId, setSelectedMaterialIds]);

  const filteredMaterials = useMemo(() => {
    const query = search.trim().toLowerCase();
    return courseMaterials.filter(({ name }) => !query || name.toLowerCase().includes(query));
  }, [courseMaterials, search]);

  const profileContent = (
    <>
      <h3 className="side-heading">Workspace Scope</h3>
      <div className="side-list">
        <div className="side-item"><strong>Course</strong><span>{currentCourse ? `${currentCourse.code} ${currentCourse.name}` : "Not selected"}</span></div>
        <div className="side-item"><strong>Materials</strong><span>{selectedMaterials.length ? `${selectedMaterials.length} selected` : "Not selected"}</span></div>
        <div className="side-item"><strong>Summary Uses</strong><span>{summaryUses}</span></div>
        <div className="side-item"><strong>Q&amp;A Uses</strong><span>{qaUses}</span></div>
      </div>
    </>
  );

  return (
    <StudentLayout
      profileProps={{ title: "Study Workspace", initials: "AI", name: currentCourse?.code || "Select Course", subtitle: "Summary, Q&A, and Quiz use selected course materials." }}
      profileContent={profileContent}
    >
      <Toolbar value={search} onChange={setSearch} placeholder="Search materials in current course..." />
      <header className="workspace-header">
        <h1>Study Workspace</h1>
        <p>Choose a course and the materials Summary, Q&amp;A, and Quiz should use.</p>
      </header>
      <div className="control-grid">
        <label className="user-field">
          Current Course
          <select value={currentCourseId} onChange={(event) => selectCourse(event.target.value)}>
            {studentCourses.map((course) => <option key={course.id} value={course.id}>{course.code} {course.name}</option>)}
          </select>
        </label>
      </div>
      <MaterialSelector materials={courseMaterials} filteredMaterials={filteredMaterials} selectedMaterialIds={selectedMaterialIds} onSelectionChange={setSelectedMaterialIds} />
      {currentCourse && courseMaterials.length > 0 && !selectedMaterials.length && (
        <div className="state-banner error"><AlertCircle size={16} /> Please select at least one material before using Summary, Q&amp;A, or Quiz.</div>
      )}
      <div className="workspace-tabs">
        {STUDY_MODES.map(([key, label, Icon]) => (
          <button key={key} type="button" className={mode === key ? "active" : ""} onClick={() => setMode(key)}><Icon size={16} /> {label}</button>
        ))}
      </div>
      {mode === "summary" && <SummaryPanel canUseAI={canUseAI} materialSourceLabel={materialSourceLabel} selectedMaterials={selectedMaterials} onGenerated={recordSummaryUse} />}
      {mode === "qa" && <QAPanel currentCourse={currentCourse} materialSourceLabel={materialSourceLabel} selectedMaterials={selectedMaterials} />}
      {mode === "quiz" && <QuizPanel canUseAI={canUseAI} materialSourceLabel={materialSourceLabel} selectedMaterialIds={selectedMaterialIds} onCompleted={saveQuizAttempt} />}
    </StudentLayout>
  );
}
